﻿using UnityEngine;
using Obi;
using System.Linq;

[RequireComponent(typeof(ObiActor))]
public class ObiActorLogger : Logger
{
    // Log how much obi particles are positioned in certain detectioncolliders in the scene. Needs an Obi Actor (Obi Emitter is also an Obi Actor).
    [ReadOnly]
    public string[] reportHeaders = new string[4] {
    "Particles in Bath",
    "Particles in Bin 1",
    "Particles in Bin 2",
    "Total particles"
    };

    [ReadOnly]
    public int inBath = 0;
    [ReadOnly]
    public int[] inBin;
    [ReadOnly]
    public float fraction = 1.0f;
    [ReadOnly]
    public int numParticles = 0;

    [Header("Logger Specific Settings")] // Create a header for any logger specific settings
    [SerializeField] public string fileNamePrefix = "OBI_";
    [SerializeField]
    [Tooltip("Optionally: Set this > 0 to refresh the data every x seconds to prevent heavy CPU load. ")] float refreshTime = 0.1f;

    [SerializeField] Collider[] detectionRangeZinc = null;
    [SerializeField] Collider[] detectionRangeBin = null;
    [SerializeField] bool requireBinDeposit = true;

    ObiActor m_actor = null;
    private CustomFixedUpdate FU_instance;

    private string[] data;

    private void Start()
    {
        Initialize();

        m_actor = GetComponent<ObiActor>();

        if (refreshTime > 0.0f)
            FU_instance = new CustomFixedUpdate(refreshTime, OnFixedUpdate); //so that the updating rate can be changed as it is quite cpu intensive (a LOT of data to process)
    }

    private void Update()
    {
        if (FU_instance != null && refreshTime > 0)
            FU_instance.Update();
    }

    #region DrossDetection

    private void OnFixedUpdate(float dt)
    {
        fixedUpdateFunc();
    }

    public void fixedUpdateFunc() // run this function to make one log (only do this at the important times, running it at regular intervals using the fixedupdate is really intensive
    {
        if (detectionRangeZinc.Length>0)
        {
            inBath = 0;
            foreach (var zinc in detectionRangeZinc)
            {
                inBath += scanBathForDross(zinc); // These are quite resource intensive, might consider doing them at larger intervals
            }
        }
        else inBath = -1; // make it -1 to show that this data is missing

        if (detectionRangeBin.Length>0) inBin = scanBinsForDross();

        if (m_actor.isLoaded)
        {
            numParticles = m_actor.particleCount;
            if (requireBinDeposit)
            {
                fraction = ((numParticles - inBin.Sum())/ (float)numParticles);
            }
            else
            {
                fraction = (inBath / (float)numParticles);
            }

            data = new string[4] 
            {
                inBath.ToString(),
                inBin[0].ToString(),
                inBin[1].ToString(),
                numParticles.ToString(),
            };
        }
    }

    int scanBathForDross(Collider coll)
    {
        int detected = 0;
        for (int i = 0; i < m_actor.particleCount; i++)
        {
            int solverIndex = m_actor.solverIndices[i];

            Vector3 CP = coll.ClosestPoint(m_actor.GetParticlePosition(solverIndex));

            if ((CP - m_actor.GetParticlePosition(solverIndex)).magnitude == 0) detected++;
        }

        return detected;
    }
    int[] scanBinsForDross()
    {
        var Nbins = detectionRangeBin.Length;
        int[] detected = new int[Nbins]; 

        if (detectionRangeBin.Length > 0)
        {
            for (int i = 0; i < m_actor.particleCount; i++)
            {
                int solverIndex = m_actor.solverIndices[i];

                // could put all this in a loop, but this is a bit cleaner, as theres only 2 bins anyway...
                Vector3[] CP = new Vector3[Nbins];
                CP[0] = detectionRangeBin[0].ClosestPoint(m_actor.GetParticlePosition(solverIndex));
                CP[1] = detectionRangeBin[1].ClosestPoint(m_actor.GetParticlePosition(solverIndex));

                if ((CP[0] - m_actor.GetParticlePosition(solverIndex)).magnitude == 0) detected[0]++;
                if ((CP[1] - m_actor.GetParticlePosition(solverIndex)).magnitude == 0) detected[1]++;
            }
        }
        else
            Debug.LogError("Can't find detectionRangeBin");

        return detected;
    }
    #endregion

    public string[] getData()
    {
        return data;
    }

}