﻿using UnityEngine;

[RequireComponent(typeof(HapticPlugin))]
public class OmniLogger : Logger
{
    HapticPlugin hapticPlugin;

    [HideInInspector] public string[] reportHeaders = new string[18] {
        "ConfigName",
        "Stiffness",
        "Damping",
        "Stylus Force X",
        "Stylus Force Y",
        "Stylus Force Z",
        "Stylus Force Magnitude",
        "stylusPositionRaw X",
        "stylusPositionRaw Y",
        "stylusPositionRaw Z",
        "stylusVelocityRaw X",
        "stylusVelocityRaw Y",
        "stylusVelocityRaw Z",
        "stylusVelocityRaw Magnitude",
        "stylusRotationWorld X",
        "stylusRotationWorld Y",
        "stylusRotationWorld Z",
        "stylusRotationWorld W",
    };

    [Header("Logger Specific Settings")] // Create a header for any logger specific settings
    [SerializeField] public string fileNamePrefix = "OMNI_";

    void Start()
    {
        Initialize();

        hapticPlugin = FindObjectOfType<HapticPlugin>();
    }

    public string[] getData()
    {
        Vector3 anchorPos = hapticPlugin.hapticManipulator.GetComponent<Rigidbody>().transform.position;
        Vector3 anchorVel = hapticPlugin.hapticManipulator.GetComponent<Rigidbody>().velocity;
        Vector3 deltaPos = anchorPos - hapticPlugin.stylusPositionRaw;
        Vector3 force = (float)hapticPlugin.PhysicsForceStrength * deltaPos - (float)hapticPlugin.PhysicsForceDamping * (hapticPlugin.stylusVelocityRaw - anchorVel); // apparently damping isn't used by default, left the code here anyway
        // force = k*x - b*u
        
        string[] strings = new string[18] {
                hapticPlugin.configName,
                hapticPlugin.PhysicsForceStrength.ToString(),
                hapticPlugin.PhysicsForceDamping.ToString(),
                force.x.ToString(),
                force.y.ToString(),
                force.z.ToString(),
                force.magnitude.ToString(),
                hapticPlugin.stylusPositionRaw.x.ToString(),
                hapticPlugin.stylusPositionRaw.y.ToString(),
                hapticPlugin.stylusPositionRaw.z.ToString(),
                hapticPlugin.stylusVelocityRaw.x.ToString(),
                hapticPlugin.stylusVelocityRaw.y.ToString(),
                hapticPlugin.stylusVelocityRaw.z.ToString(),
                hapticPlugin.stylusVelocityRaw.magnitude.ToString(),
                hapticPlugin.stylusRotationWorld.x.ToString(),
                hapticPlugin.stylusRotationWorld.y.ToString(),
                hapticPlugin.stylusRotationWorld.z.ToString(),
                hapticPlugin.stylusRotationWorld.w.ToString(),
        };

        return strings;
    }
}
