﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

namespace NVIDIA.Flex
{
    [RequireComponent(typeof(FlexArrayActor))]
    public class FlexArrayLogger: Logger
    {
        // Log how much of the flexarray is inside of the detectionrange
        [SerializeField] Collider detectionRange = null;

        [SerializeField] public string fileNamePrefix = "PROX_";
        [SerializeField]
        [Tooltip("Optionally: Set this > 0 to refresh the data every x seconds to prevent heavy CPU load. ")] float refreshTime = 0.2f;

        FlexArrayActor m_actor = null;
        [ReadOnly] 
        public int inRange = 0;
        [ReadOnly]
        public float fraction = 1.0f;
        [ReadOnly]
        public int numParticles = 0;

        private CustomFixedUpdate FU_instance;

        public string[] reportHeaders = new string[3] {
            "Actor Name",
            "Particles in Range",
            "Total particles"
        };

        public string[] data;

        void Start()
        {
            Initialize();

            m_actor = GetComponent<FlexArrayActor>();

            if (refreshTime>0.0f)
                FU_instance = new CustomFixedUpdate(refreshTime, OnFixedUpdate); //so that the updating rate can be changed as it is quite cpu intensive (a LOT of data to process)
        }

        private void Update()
        {
            if (FU_instance != null && refreshTime > 0)
                FU_instance.Update();
        }

        #region DrossDetection

        private void OnFixedUpdate(float dt)
        {
            fixedUpdateFunc();
        }

        public void fixedUpdateFunc() // run this function to make one log (only do this at the important times, running it at regular intervals using the fixedupdate is really intensive
        {
            if (detectionRange) 
                inRange = scanBathForDross();

            if (m_actor == null)
                return;

            fraction = (inRange / (float)m_actor.particles.Length);

            data = new string[3] {
                gameObject.name,
                inRange.ToString(),
                m_actor.particles.Length.ToString(),
            };
        }


        int scanBathForDross()
        {
            int detected = 0;
            for (int i = 0; i < m_actor.particles.Length; i++)
            {
                Vector3 CP = detectionRange.ClosestPoint(ToVector3(m_actor.particles[i]));

                if ((CP - ToVector3(m_actor.particles[i])).magnitude == 0) detected++;
            }
            return detected;
        }

        Vector3 ToVector3(Vector4 parent)
        {
            return new Vector3(parent.x, parent.y, parent.z);
        }
        #endregion

        public string[] getData()
        {
            return data;
        }

    }
}